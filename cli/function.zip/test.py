def handler(event, context):
  print("test")
  return {
    "statusCode": 200,
    "message": "test success"
  }